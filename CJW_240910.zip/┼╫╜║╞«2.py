import pygame


class Block(pygame.sprite.Sprite):
  def __init__(self,x,y):
    pygame.sprite.Sprite.__init__(self)
    self.image = pygame.image.load("images/FullBlock.png").convert_alpha()
    self.image = pygame.transform.scale(self.image, (50,50))
    self.rect = self.image.get_rect()
    self.rect.topleft = (x,y)
    self.mask = pygame.mask.from_surface(self.image)
    self.trgtjumpspd = -50
    self.jumpspd = 0
    self.gravity = 1.2
    self.jmpstatus = False

  def update(self):
    if self.jmpstatus:
      self.stickintofloor(1000,200)
  
  def jump(self):
    if not self.jmpstatus:
      self.jmpstatus = True
      self.jumpspd = self.trgtjumpspd

  def stickintofloor(self,height, flrheight):
    self.rect.y += self.jumpspd
    self.jumpspd += self.gravity
    if self.rect.bottom >= height - flrheight:
      self.rect.bottom = height - flrheight
      self.jumpspd = 0
      self.jmpstatus = False