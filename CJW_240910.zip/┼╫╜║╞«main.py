import pygame
import os
import sys
from 테스트1 import SpikeDown, SpikeRight, SpikeUp, SpikeLeft
from 테스트2 import Block

pygame.init()

SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 800
FLOOR_HEIGHT = 200
scroll_speed = 1
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("콜라이드마스크스")
BLACK = 0, 0, 0
DARKEN_SURFACE_COLOR = (50, 50, 50, 70)

pygame.mouse.set_visible(True)

spikeup = SpikeUp(800, 500)
spikedown = SpikeDown(900, 500)
spikeright = SpikeRight(1000, 500)
spikeleft = SpikeLeft(1100, 500)
player = Block(100,SCREEN_HEIGHT - FLOOR_HEIGHT - 50)

floorline = pygame.image.load("images/FloorLine.png")
floorline = pygame.transform.scale(floorline, (SCREEN_WIDTH, 10))

spike_group = pygame.sprite.Group()
block_group = pygame.sprite.Group()
spike_group.add(SpikeUp(800,500))
spike_group.add(spikedown)
spike_group.add(spikeleft)
spike_group.add(spikeright)
block_group.add(player)

i = 0
running = True
while running:

  
  screen.fill(BLACK)

  if pygame.sprite.spritecollide(player, spike_group, False, pygame.sprite.collide_mask):
    i+=1
    print("충돌감지!",i)

  block_group.update()

  spike_group.draw(screen)
  block_group.draw(screen)
  screen.blit(floorline, (0, SCREEN_HEIGHT - 200))
  darken_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT - (SCREEN_HEIGHT - 200 + 10)))
  darken_surface.set_alpha(50)
  darken_surface.fill(DARKEN_SURFACE_COLOR[:3])
  screen.blit(darken_surface, (0, SCREEN_HEIGHT - FLOOR_HEIGHT + 10))


  for spike in spike_group:
            spike.move(scroll_speed)


  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      running = False
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_SPACE:
            player.jump()
  player.update()

  pygame.display.update()

pygame.quit()