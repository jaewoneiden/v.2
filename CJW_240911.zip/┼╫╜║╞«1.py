import pygame


class SpikeUp(pygame.sprite.Sprite):
  def __init__(self, x, y):
    pygame.sprite.Sprite.__init__(self)
    self.x = x
    self.y = y
    self.image = pygame.image.load("images/SpikeUp.png").convert_alpha()
    self.image = pygame.transform.scale(self.image,(75,75))
    self.rect = self.image.get_rect()
    self.rect.topleft = (x, y)
    self.mask = pygame.mask.from_surface(self.image)
  
  def move(self, speed):
        self.x -= speed
        self.rect.topleft = (self.x, self.y)
        self.mask = pygame.mask.from_surface(self.image)

class SpikeDown(pygame.sprite.Sprite):
  def __init__(self,x,y):
    pygame.sprite.Sprite.__init__(self)
    self.x = x
    self.y = y
    self.image = pygame.image.load("images/SpikeDown.png").convert_alpha()
    self.image = pygame.transform.scale(self.image,(75,75))
    self.rect = self.image.get_rect()
    self.rect.topleft = (x, y)
    self.mask = pygame.mask.from_surface(self.image)

  def move(self, speed):
        self.x -= speed
        self.rect.topleft = (self.x, self.y)
        self.mask = pygame.mask.from_surface(self.image)

class SpikeLeft(pygame.sprite.Sprite):
  def __init__(self, x, y):
    pygame.sprite.Sprite.__init__(self)
    self.x = x
    self.y = y
    self.image = pygame.image.load("images/SpikeLeft.png").convert_alpha()
    self.image = pygame.transform.scale(self.image,(75,75))
    self.rect = self.image.get_rect()
    self.rect.topleft = (x, y)
    self.mask = pygame.mask.from_surface(self.image)

  def move(self, speed):
        self.x -= speed
        self.rect.topleft = (self.x, self.y)
        self.mask = pygame.mask.from_surface(self.image)

class SpikeRight(pygame.sprite.Sprite):
  def __init__(self, x, y):
    pygame.sprite.Sprite.__init__(self)
    self.x = x
    self.y = y
    self.image = pygame.image.load("images/SpikeRight.png").convert_alpha()
    self.image = pygame.transform.scale(self.image,(75,75))
    self.rect = self.image.get_rect()
    self.rect.topleft = (x, y)
    self.mask = pygame.mask.from_surface(self.image)

  def move(self, speed):
        self.x -= speed
        if self.x + self.rect.width < 0:
            self.x = 30000  # 맵 끝에 다시 배치
        self.rect.topleft = (self.x, self.y)
        self.mask = pygame.mask.from_surface(self.image)