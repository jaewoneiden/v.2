import pygame
import os
import sys
from 테스트1 import SpikeDown, SpikeRight, SpikeUp, SpikeLeft
from 테스트2 import Player

pygame.init()

SCREEN_WIDTH = 1200
SCREEN_HEIGHT = 800
FLOOR_HEIGHT = 200
scroll_speed = 3
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("콜라이드마스크스")
BLACK = 0, 0, 0
DARKEN_SURFACE_COLOR = (50, 50, 50, 70)

pygame.mouse.set_visible(True)

player = Player(100,SCREEN_HEIGHT - FLOOR_HEIGHT - 50)

floorline = pygame.image.load("images/FloorLine.png")
floorline = pygame.transform.scale(floorline, (SCREEN_WIDTH, 10))

spike_group = pygame.sprite.Group()
block_group = pygame.sprite.Group()
object_group = pygame.sprite.Group()
spike_group.add(SpikeUp(800,525))
spike_group.add(SpikeUp(900,525))
spike_group.add(SpikeUp(1000,525))
spike_group.add(SpikeUp(1100,525))
block_group.add(player)
clock = pygame.time.Clock()

i = 0
running = True
while running:

  
  screen.fill(BLACK)

  if pygame.sprite.spritecollide(player, spike_group, False, pygame.sprite.collide_mask):
    i+=1
    print("충돌감지!",i)
  if pygame.sprite.spritecollide(player, object_group, False, pygame.sprite.collide_mask):
      if spike_group.
    

  block_group.update()

  spike_group.draw(screen)
  block_group.draw(screen)
  screen.blit(floorline, (0, SCREEN_HEIGHT - 200))
  darken_surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT - (SCREEN_HEIGHT - 200 + 10)))
  darken_surface.set_alpha(50)
  darken_surface.fill(DARKEN_SURFACE_COLOR[:3])
  screen.blit(darken_surface, (0, SCREEN_HEIGHT - FLOOR_HEIGHT + 10))


  for spike in spike_group:
            spike.move(scroll_speed)


  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      running = False
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_SPACE:
            player.jump()
  player.update()
  clock.tick(60)

  pygame.display.update()

pygame.quit()